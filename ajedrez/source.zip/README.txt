INSTRUCCIONES PARA COMPILAR Y EJECUTAR
usar 
en la carpeta donde est� el archivo gradlew

sudo ./gradlew run