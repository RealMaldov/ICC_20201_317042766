package chess.pieces;
public enum ColorEnum{
    WHITE,
    BLACK,
    NONE
}