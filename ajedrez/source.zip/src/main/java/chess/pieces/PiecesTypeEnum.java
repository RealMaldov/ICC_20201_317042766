package chess.pieces;
public enum PiecesTypeEnum{
    EMPTY,
    ROOK,
    QUEEN
}